package test;
import monopoly.Board;
import monopoly.Square;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll; // added
import org.junit.jupiter.api.AfterAll; // added
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
/**
 * The test class BoardTest.
 *
 * @author Amina Hajiyeva 101303729
 */
public class BoardTest
{
    private Board board;
    
    @BeforeAll
    public static void init() 
    {
        System.out.println("init() ran");
    }

    @AfterAll
    public static void close() 
    {
        System.out.println("close() ran");
    }

    @BeforeEach
    public void setUp() 
    {
        board = new Board();
        System.out.println("setUp() ran");
    }

    @AfterEach
    public void tearDown() 
    {
        System.out.println("tearDown() ran");
    }

    // a. Test that the starting square of a new board is square number 1.
    @Test
    public void testStartingSquare() 
    {
        System.out.println("Running testStartingSquare...");
        Square start = board.startingSquare();
        assertEquals(1, start.number());
    }

    // b. Test that the squares are numbered consecutively from 1 to 40
    @Test
    public void testConsecutiveNumbering() 
    {
        System.out.println("Running testConsecutiveNumbering...");
        Square current = board.startingSquare();
        for (int i = 1; i < 40; i++) 
        {
            Square next = board.nextSquare(current, 1);
            assertEquals((current.number() % 40) + 1, next.number());
            current = next;
        }
    }

    // c. Test that nextSquare() works properly for distances between 2 and 12
    @Test
    public void testNextSquareDistance2to12() 
    {
        System.out.println("Running testNextSquareDistance2to12...");
        Square current = board.startingSquare();
        for (int distance = 2; distance <= 12; distance++) 
        {
            Square destination = board.nextSquare(current, distance);
            int expected = ((current.number() - 1 + distance) % 40) + 1;
            assertEquals(expected, destination.number());
        }
    }

    // d. Test that the board wraps around properly
    @Test
    public void testWrapAroundFromEnd() 
    {
        System.out.println("Running testWrapAroundFromEnd...");
        // Go to square 39 (array index 38), then move forward 2 to wrap
        Square square39 = board.nextSquare(board.startingSquare(), 38);
        assertEquals(39, square39.number());

        Square square40 = board.nextSquare(square39, 1);
        assertEquals(40, square40.number());

        Square wrapped = board.nextSquare(square40, 1);
        assertEquals(1, wrapped.number()); // should wrap to square 1
    }
}
