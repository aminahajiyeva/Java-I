package test;
import monopoly.Dice;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll; // added
import org.junit.jupiter.api.AfterAll; // added
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
/**
 * The test class DiceTest.
 *
 * @author Amina Hajiyeva 101303729
 */
public class DiceTest
{
    private Dice dice;

    @BeforeAll
    public static void init() 
    {
        System.out.println("init() ran");
    }

    @AfterAll
    public static void close() 
    {
        System.out.println("close() ran");
    }

    @BeforeEach
    public void setUp() 
    {
        System.out.println("setUp() ran");
        dice = new Dice();
    }

    @AfterEach
    public void tearDown() 
    {
        System.out.println("tearDown() ran");
    }

    @Test
    public void testDiceRollRange() 
    {
        System.out.println("Running testDiceRollRange..."); 
        for (int i = 0; i < 1000; i++) 
        {
            int roll = dice.roll();
            assertTrue(roll >= 2 && roll <= 12, "Roll out of bounds: " + roll);
        }
    }
}
