package test;
import monopoly.Square;
import monopoly.Money;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll; // added
import org.junit.jupiter.api.AfterAll; // added
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
/**
 * The test class SquareTest.
 *
 * @author Amina Hajiyeva 101303729
 */
public class SquareTest
{
    @BeforeAll
    public static void init() 
    {
        System.out.println("init() ran");
    }

    @AfterAll
    public static void close() 
    {
        System.out.println("close() ran");
    }

    @BeforeEach
    public void setUp() 
    {
        System.out.println("setUp() ran");
    }

    @AfterEach
    public void tearDown() 
    {
        System.out.println("tearDown() ran");
    }

    @Test
    public void testGoSquare() 
    {
        System.out.println("Testing GO square...");
        Square go = new Square(Square.GO, "Go", 1);
        assertEquals(Square.GO, go.type());
        assertEquals("Go", go.name());
        assertEquals(1, go.number());
        assertTrue(go.salary().isEqualTo(new Money(200, 0)));
        assertNull(go.price());
        assertNull(go.maximumTax());
    }

    @Test
    public void testLotSquare() 
    {
        System.out.println("Testing LOT square...");
        Square lot = new Square(Square.LOT, "Duckworth Street", 2);
        Money price = new Money(60, 0);
        lot.setPrice(price);
        assertEquals(Square.LOT, lot.type());
        assertEquals("Duckworth Street", lot.name());
        assertEquals(2, lot.number());
        assertEquals(price.toString(), lot.price().toString());
        assertNull(lot.salary());
        assertNull(lot.maximumTax());
    }

    @Test
    public void testIncomeTaxSquare() 
    {
        System.out.println("Testing INCOME_TAX square...");
        Square tax = new Square(Square.INCOME_TAX, "Income Tax", 5);
        assertEquals(Square.INCOME_TAX, tax.type());
        assertEquals("Income Tax", tax.name());
        assertEquals(5, tax.number());
        assertTrue(tax.maximumTax().isEqualTo(new Money(200, 0)));
        assertNull(tax.salary());
        assertNull(tax.price());
    }

    @Test
    public void testEmptySquare() 
    {
        System.out.println("Testing EMPTY square...");
        Square empty = new Square(Square.EMPTY, "Chance", 8);
        assertEquals(Square.EMPTY, empty.type());
        assertEquals("Chance", empty.name());
        assertEquals(8, empty.number());
        assertNull(empty.salary());
        assertNull(empty.price());
        assertNull(empty.maximumTax());
    }
}